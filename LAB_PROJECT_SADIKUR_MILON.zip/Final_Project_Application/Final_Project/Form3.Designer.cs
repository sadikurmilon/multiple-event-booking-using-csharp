﻿namespace Final_Project
{
    partial class Receipt_frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Receipt_frm));
            this.address_lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.event_nme_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lcation_lbl = new System.Windows.Forms.Label();
            this.date_tme_lbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tax_lbl = new System.Windows.Forms.Label();
            this.tckt_prce_lbl = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.phn_lbl = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.payer_lbl = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.seat_lbl = new System.Windows.Forms.Label();
            this.prce_tax_lbl = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.card_lbl = new System.Windows.Forms.Label();
            this.card_total_lbl = new System.Windows.Forms.Label();
            this.clse_bttn = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.thisButtonWillHelpYouToExitTheProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // address_lbl
            // 
            this.address_lbl.AutoSize = true;
            this.address_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.address_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.address_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address_lbl.Location = new System.Drawing.Point(113, 262);
            this.address_lbl.Name = "address_lbl";
            this.address_lbl.Size = new System.Drawing.Size(2, 26);
            this.address_lbl.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(249, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "Event:";
            // 
            // event_nme_lbl
            // 
            this.event_nme_lbl.AutoSize = true;
            this.event_nme_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.event_nme_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.event_nme_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.event_nme_lbl.Location = new System.Drawing.Point(326, 42);
            this.event_nme_lbl.Name = "event_nme_lbl";
            this.event_nme_lbl.Size = new System.Drawing.Size(2, 26);
            this.event_nme_lbl.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(249, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "Location:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(249, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 26);
            this.label5.TabIndex = 4;
            this.label5.Text = "Date/Time:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(249, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "Seat(s):";
            // 
            // lcation_lbl
            // 
            this.lcation_lbl.AutoSize = true;
            this.lcation_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.lcation_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lcation_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lcation_lbl.Location = new System.Drawing.Point(352, 78);
            this.lcation_lbl.Name = "lcation_lbl";
            this.lcation_lbl.Size = new System.Drawing.Size(2, 26);
            this.lcation_lbl.TabIndex = 6;
            // 
            // date_tme_lbl
            // 
            this.date_tme_lbl.AutoSize = true;
            this.date_tme_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.date_tme_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.date_tme_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_tme_lbl.Location = new System.Drawing.Point(368, 118);
            this.date_tme_lbl.Name = "date_tme_lbl";
            this.date_tme_lbl.Size = new System.Drawing.Size(2, 26);
            this.date_tme_lbl.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 419);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 26);
            this.label9.TabIndex = 8;
            this.label9.Text = "Total:";
            // 
            // tax_lbl
            // 
            this.tax_lbl.AutoSize = true;
            this.tax_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tax_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tax_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tax_lbl.Location = new System.Drawing.Point(131, 377);
            this.tax_lbl.Name = "tax_lbl";
            this.tax_lbl.Size = new System.Drawing.Size(2, 26);
            this.tax_lbl.TabIndex = 9;
            // 
            // tckt_prce_lbl
            // 
            this.tckt_prce_lbl.AutoSize = true;
            this.tckt_prce_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tckt_prce_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tckt_prce_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tckt_prce_lbl.Location = new System.Drawing.Point(146, 341);
            this.tckt_prce_lbl.Name = "tckt_prce_lbl";
            this.tckt_prce_lbl.Size = new System.Drawing.Size(2, 26);
            this.tckt_prce_lbl.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Brown;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(12, 300);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(207, 26);
            this.label12.TabIndex = 11;
            this.label12.Text = "Payment Information:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(12, 341);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 26);
            this.label13.TabIndex = 12;
            this.label13.Text = "Ticket Price:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 377);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 26);
            this.label14.TabIndex = 13;
            this.label14.Text = "Tax(13%):";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Gold;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(93, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(394, 24);
            this.label15.TabIndex = 14;
            this.label15.Text = "THANK YOU FOR PURCHASING TICKET";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(12, 262);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 26);
            this.label17.TabIndex = 16;
            this.label17.Text = "Address:";
            // 
            // phn_lbl
            // 
            this.phn_lbl.AutoSize = true;
            this.phn_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.phn_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.phn_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phn_lbl.Location = new System.Drawing.Point(97, 225);
            this.phn_lbl.Name = "phn_lbl";
            this.phn_lbl.Size = new System.Drawing.Size(2, 26);
            this.phn_lbl.TabIndex = 17;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(12, 225);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 26);
            this.label19.TabIndex = 18;
            this.label19.Text = "Phone:";
            // 
            // payer_lbl
            // 
            this.payer_lbl.AutoSize = true;
            this.payer_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.payer_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.payer_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payer_lbl.Location = new System.Drawing.Point(89, 186);
            this.payer_lbl.Name = "payer_lbl";
            this.payer_lbl.Size = new System.Drawing.Size(2, 26);
            this.payer_lbl.TabIndex = 19;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(12, 186);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(71, 26);
            this.label21.TabIndex = 20;
            this.label21.Text = "Payer:";
            // 
            // seat_lbl
            // 
            this.seat_lbl.AutoSize = true;
            this.seat_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.seat_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.seat_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seat_lbl.Location = new System.Drawing.Point(338, 156);
            this.seat_lbl.Name = "seat_lbl";
            this.seat_lbl.Size = new System.Drawing.Size(2, 26);
            this.seat_lbl.TabIndex = 21;
            // 
            // prce_tax_lbl
            // 
            this.prce_tax_lbl.AutoSize = true;
            this.prce_tax_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.prce_tax_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.prce_tax_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prce_tax_lbl.Location = new System.Drawing.Point(82, 419);
            this.prce_tax_lbl.Name = "prce_tax_lbl";
            this.prce_tax_lbl.Size = new System.Drawing.Size(2, 26);
            this.prce_tax_lbl.TabIndex = 22;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(342, 377);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(64, 26);
            this.label23.TabIndex = 23;
            this.label23.Text = "Total:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Brown;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(342, 300);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(174, 26);
            this.label24.TabIndex = 24;
            this.label24.Text = "Payment Method:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(342, 341);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 26);
            this.label25.TabIndex = 25;
            this.label25.Text = "Card:";
            // 
            // card_lbl
            // 
            this.card_lbl.AutoSize = true;
            this.card_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.card_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.card_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.card_lbl.Location = new System.Drawing.Point(427, 341);
            this.card_lbl.Name = "card_lbl";
            this.card_lbl.Size = new System.Drawing.Size(117, 26);
            this.card_lbl.TabIndex = 26;
            this.card_lbl.Text = "Credit Card";
            // 
            // card_total_lbl
            // 
            this.card_total_lbl.AutoSize = true;
            this.card_total_lbl.BackColor = System.Drawing.SystemColors.ControlDark;
            this.card_total_lbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.card_total_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.card_total_lbl.Location = new System.Drawing.Point(427, 377);
            this.card_total_lbl.Name = "card_total_lbl";
            this.card_total_lbl.Size = new System.Drawing.Size(2, 26);
            this.card_total_lbl.TabIndex = 27;
            // 
            // clse_bttn
            // 
            this.clse_bttn.BackColor = System.Drawing.Color.Red;
            this.clse_bttn.ContextMenuStrip = this.contextMenuStrip1;
            this.clse_bttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clse_bttn.Location = new System.Drawing.Point(508, 422);
            this.clse_bttn.Name = "clse_bttn";
            this.clse_bttn.Size = new System.Drawing.Size(153, 39);
            this.clse_bttn.TabIndex = 28;
            this.clse_bttn.Text = "Close";
            this.clse_bttn.UseVisualStyleBackColor = false;
            this.clse_bttn.Click += new System.EventHandler(this.clse_bttn_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thisButtonWillHelpYouToExitTheProgramToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(310, 26);
            // 
            // thisButtonWillHelpYouToExitTheProgramToolStripMenuItem
            // 
            this.thisButtonWillHelpYouToExitTheProgramToolStripMenuItem.Name = "thisButtonWillHelpYouToExitTheProgramToolStripMenuItem";
            this.thisButtonWillHelpYouToExitTheProgramToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.thisButtonWillHelpYouToExitTheProgramToolStripMenuItem.Text = "This button will help you to exit the program";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(177, 141);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(582, 26);
            // 
            // thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem
            // 
            this.thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem.Name = "thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxTool" +
    "StripMenuItem";
            this.thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem.Size = new System.Drawing.Size(581, 22);
            this.thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem.Text = "This form is your receipt for your event. You will find how much you were charged" +
    " including tax.";
            // 
            // Receipt_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(673, 473);
            this.ContextMenuStrip = this.contextMenuStrip2;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.clse_bttn);
            this.Controls.Add(this.card_total_lbl);
            this.Controls.Add(this.card_lbl);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.prce_tax_lbl);
            this.Controls.Add(this.seat_lbl);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.payer_lbl);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.phn_lbl);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tckt_prce_lbl);
            this.Controls.Add(this.tax_lbl);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.date_tme_lbl);
            this.Controls.Add(this.lcation_lbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.event_nme_lbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.address_lbl);
            this.Name = "Receipt_frm";
            this.Text = "RECEIPT";
            this.Load += new System.EventHandler(this.Receipt_frm_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label address_lbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label event_nme_lbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lcation_lbl;
        private System.Windows.Forms.Label date_tme_lbl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label tax_lbl;
        private System.Windows.Forms.Label tckt_prce_lbl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label phn_lbl;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label payer_lbl;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label seat_lbl;
        private System.Windows.Forms.Label prce_tax_lbl;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label card_lbl;
        private System.Windows.Forms.Label card_total_lbl;
        private System.Windows.Forms.Button clse_bttn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem thisButtonWillHelpYouToExitTheProgramToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem thisFormIsYourReceiptForYourEventYouWillFindHowMuchYouWereChargedIncludingTaxToolStripMenuItem;
    }
}